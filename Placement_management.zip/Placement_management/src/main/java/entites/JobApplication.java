package entites;



import javax.persistence.*;
import java.util.Date;

@Entity
@Table(name = "job_application")
public class JobApplication {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "application_id")
    private int applicationId;
    
    @ManyToOne
    @JoinColumn(name = "student_id", referencedColumnName = "student_id")
    private Student student;
    
    @ManyToOne
    @JoinColumn(name = "job_id", referencedColumnName = "job_id")
    private Job job;
    
    @Column(name = "application_date")
    private Date applicationDate;
    
    @Column(name = "status")
    private String status;
    
    @ManyToOne
    @JoinColumn(name = "company_id", referencedColumnName = "company_id")
    private Company company;

    // Getters and setters
}

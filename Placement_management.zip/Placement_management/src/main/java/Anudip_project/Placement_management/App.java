package Anudip_project.Placement_management;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import java.util.Scanner;

import ServiceImplementation.StudentCredentialServiceImpl;
import opertationals.HodOperatation;
import opertationals.StudentOperation;



public class App 
{
	public static void main(String[] args) {
		//
		Configuration config = new Configuration().configure("hibernate.cfg.xml");
		SessionFactory sfg = config.buildSessionFactory();
		Session session = sfg.openSession();
		Transaction tx = session.beginTransaction();

		
		//
		
		//
        System.out.println("Enter your choice");
        System.out.println("1.Student");
        System.out.println("2.Hod");
        System.out.println("3.Collage");
        System.out.println("4.admin");
        Scanner s = new Scanner(System.in);
        int choice = s.nextInt();
        switch (choice) {
            case 1:
                System.out.println("Student selected");
                System.out.println("Enter Username");
                StudentCredentialServiceImpl chcekcrendital=new StudentCredentialServiceImpl();
                String username =s.next();
                
                if(chcekcrendital.isUsernameTaken(session, username))
                {
                	System.out.println("Enter Password");
                	String password =s.next();
                	if(chcekcrendital.authenticate(session, username, password))
                	{
                		System.out.println("You are authorized user");
                		 String stdid= chcekcrendital.getStudentIdByCredentials(session, username, password);
                		StudentOperation std= new StudentOperation();
                        std.stdmenu(stdid);
                	}
                	else
                	{
                		System.out.println("incorrect crendital");
                	}
                	
                }
                else
                {
                	System.out.println("error: Invalid user name");
                }
                		
                
                
                // Add code for student functionality
                break;
            case 2:
                System.out.println("HOD selected");
                HodOperatation hod=new HodOperatation();
                hod.main(args);
                
                // Add code for HOD functionality
                break;
            case 3:
                System.out.println("College selected");
                // Add code for college functionality
                break;
            case 4:
                System.out.println("Admin selected");
                // Add code for admin functionality
                break;
            default:
                System.out.println("Invalid choice");
                // Add code for handling invalid choices
        }
    }
}

package service;

import java.util.List;
import org.hibernate.Session;
import entites.Department;
import entites.Student;

public interface StudentPersionalServices {
    void registerStudent(Session session,String StudentID, String name, String phone, String email, String fatherName,
            String address, Department department);

    boolean updateStudentName(Session session, int studentId, String name);

    boolean updateStudentPhone(Session session, int studentId, String phone);

    boolean updateStudentEmail(Session session, int studentId, String email);

    boolean updateStudentFatherName(Session session, int studentId, String fatherName);

    boolean updateStudentAddress(Session session, int studentId, String address);

    boolean updateStudentDepartment(Session session, int studentId, Department department);

    boolean deleteStudent(Session session, int studentId);

    Student getStudentById(Session session, String studentId);
   
    boolean checkStudentId(Session session, String studentId);

    List<Student> getAllStudents(Session session);
}

package opertationals;

import java.util.Scanner;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import ServiceImplementation.StudentEducationServiceImplement;
import ServiceImplementation.StudentPersonalServicesImpl;
import entites.Department;
import entites.EducationDetails;
import entites.Student;

public class StudentOperation {
	public static void  stdmenu(String studentid) 
	{
		Configuration config = new Configuration().configure("hibernate.cfg.xml");
        SessionFactory sfg = config.buildSessionFactory();
        Session session = sfg.openSession();
        Transaction tx = session.beginTransaction();

        
        Scanner s = new Scanner(System.in);
        
        // after lgin student get id
        //System.out.println("Enter Student ID");
        String StudentID ="";
        if(!(studentid==null))
        {
        	 StudentID = studentid;
        }
        else
        {
        	System.out.println("somthing went wrong");
        }
        
//        ---------------------------------------------------------
        System.out.println("Student menu");
        System.out.println("1.Student Persional details");
        System.out.println("2.Student Education details");
        System.out.println("3.Jobs");
        System.out.println("4 applyed jobs");
        System.out.println("5 appliyed job status");
        System.out.println("6 password change");
        
        System.out.println("Enter choice");
        int choice = s.nextInt();
//        global
        StudentPersonalServicesImpl std = new StudentPersonalServicesImpl();        
        switch (choice) {
            case 1:
                
                System.out.println("Persional Details");
                
                if(std.checkStudentId(session, StudentID))
                {
                	Student student = std.getStudentById(session, StudentID);
                	System.out.println("Student ID: " + student.getStudentId());
                    System.out.println("Name: " + student.getName());
                    System.out.println("Phone: " + student.getPhone());
                    System.out.println("Email: " + student.getEmail());
                    System.out.println("Father's Name: " + student.getFatherName());
                    System.out.println("Address: " + student.getAddress());
                    Department dp= student.getStudentDepartment();
                    String dpname=dp.getDepartmentName();
                    System.out.println("Department: " + dpname); // Assuming department is stored as a String
                }
                else
                {
                	System.out.println(" invalid student id");
                }
                  
                session.close();
                break;
                case 2:
                	//
//                	// enter education details 
                	// check first Student ID
                	StudentEducationServiceImplement stdedu = new StudentEducationServiceImplement();
                	if(stdedu.checkEducationByStudentId(session, StudentID))
                    {
                		EducationDetails edustd=new EducationDetails();
                		System.out.println("10th_board: " + edustd.getTwelfthBoard());
                        System.out.println("12th_board: " + edustd.getTwelfthBoard());
                        System.out.println("10th marks: " + edustd.getTenthMarks());
                        System.out.println("12th marks: " + edustd.getTwelfthMarks());
                        System.out.println("Corrent Course: " + edustd.getCurrentCourse());
                        System.out.println("Current percentage: " + edustd.getAveragePercentage());
                    }
                    else
                    {
                    	if(std.checkStudentId(session, StudentID))
                    	{
                    		System.out.println("Errot Student education detials not insert by hod");
                    	}
                    	else
                    	{
                    		System.out.println("Student data not registerd invalid student id");
                    	}
                    	
                    	
                    }
                break;
                case 3:
                	//
//                	password change
                break;
                
            default:
                System.out.println("Invalid choice");
        }

        sfg.close();
	}
    public static void main(String[] args) {
        
    }
}

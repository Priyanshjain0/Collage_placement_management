package opertationals;

import java.util.Scanner;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import ServiceImplementation.StudentCredentialServiceImpl;
import ServiceImplementation.StudentEducationServiceImplement;
import ServiceImplementation.StudentPersonalServicesImpl;
import entites.Department;
import entites.StudentCredential;

public class HodOperatation {

    public static void main(String[] args) {
        Configuration config = new Configuration().configure("hibernate.cfg.xml");
        SessionFactory sfg = config.buildSessionFactory();
        Session session = sfg.openSession();
        Transaction tx = session.beginTransaction();

        System.out.println("HOD menu");
        System.out.println("1. Student Registration");
        System.out.println("2. Student details Update");
        System.out.println("3. All students department wise");
        System.out.println("4. Jobs");
        System.out.println("5. Job application department wise");
        System.out.println("6. Password change");

        Scanner s = new Scanner(System.in);
        System.out.println("Enter choice");

        int choice = s.nextInt();
        switch (choice) {
            case 1:
                System.out.println("Student Registration selected");
                System.out.println("Enter Student ID:");
                String studentID = s.next();

                System.out.println("1. Enter Personal Details");
                System.out.println("2. Enter Education Details");
                System.out.println("Enter choice:");

                StudentPersonalServicesImpl std = new StudentPersonalServicesImpl();
                int c = s.nextInt();
                switch (c) {
                    case 1:
                        if (!std.checkStudentId(session, studentID)) {
                            System.out.print("Name: ");
                            String name = s.next();
                            System.out.print("Phone: ");
                            String phone = s.next();
                            System.out.print("Email: ");
                            String email = s.next();
                            System.out.print("Father's Name: ");
                            String fatherName = s.next();
                            System.out.print("Address: ");
                            String address = s.next();
                            System.out.print("Department: ");
                            String departmentName = s.next();

                            Department department = (Department) session.createQuery("FROM Department d WHERE d.departmentName = :departmentName")
                                    .setParameter("departmentName", departmentName)
                                    .uniqueResult();

                            if (department != null) {
                                std.registerStudent(session, studentID, name, phone, email, fatherName, address, department);
                                System.out.println("Student personal details successfully entered");

                                // Automatic insertion of student credential with username as name+studentID and password as phone
                                StudentCredentialServiceImpl credentialService = new StudentCredentialServiceImpl();
                                credentialService.credentialRegister(session, studentID, name + studentID, phone);

                                tx.commit();
                                System.out.println("Student user ID and password generated");
                                System.out.println("Username: " + name + studentID);
                                System.out.println("Password: " + phone);
                            } else {
                                System.out.println("Error: Department not registered. Please choose a valid department.");
                            }
                        } else {
                            System.out.println("Error: You are already registered");
                        }
                        break;

                    case 2:
                        if (std.checkStudentId(session, studentID)) {
                            System.out.println("Enter Education Details");
                            System.out.print("Enter Tenth Marks: ");
                            float tenthMarks = s.nextFloat();
                            System.out.print("Enter Twelfth Marks: ");
                            float twelfthMarks = s.nextFloat();
                            System.out.print("Enter Tenth Board: ");
                            String tenthBoard = s.next();
                            System.out.print("Enter Twelfth Board: ");
                            String twelfthBoard = s.next();
                            System.out.print("Enter Current Course: ");
                            String currentCourse = s.next();
                            System.out.print("Enter Average Percentage: ");
                            float averagePercentage = s.nextFloat();
                            StudentEducationServiceImplement stdedu = new StudentEducationServiceImplement();
                            stdedu.registerStudentEducation(session, studentID, tenthMarks, twelfthMarks, tenthBoard, twelfthBoard, currentCourse, averagePercentage);
                            System.out.println("Student registered successfully!");
                            tx.commit();
                            session.close();
                        } else {
                            System.out.println("Error: Must insert Personal Details before you enter");
                        }
                        break;
                }
                break;

            case 2:
                //
                //	                	password change
                break;
            case 3:
                //
                //	                	password change
                break;

            default:
                System.out.println("Invalid choice");
        }

        sfg.close();
    }
}
